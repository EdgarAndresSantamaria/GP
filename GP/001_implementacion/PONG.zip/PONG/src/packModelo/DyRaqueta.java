package packModelo;

public class DyRaqueta extends Potenciador {
	
	private int buff;

	public DyRaqueta() {
		super(5);//inicializamos el numero maximo de DyRaqueta
		initBehaviour();

	}
	
	private void initBehaviour() {
		
	}

}
