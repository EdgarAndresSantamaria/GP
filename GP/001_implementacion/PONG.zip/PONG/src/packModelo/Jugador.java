package packModelo;

public class Jugador {
	
	private String nombre;
	
	public Jugador(String pNombre) {
		nombre=pNombre;
	}

	public String getNombre() {
		return nombre;
	}
	
	

}
