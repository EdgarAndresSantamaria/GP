package packModelo;

public class Usuario extends Jugador {

	public Usuario(String pNombre) {
		super(pNombre);
	}

}
