package packMain;

import packVista.F00Inicio;
import packVista.F01MenuPrincipal;
import packVista.F04MenuJuego;
import packVista.F07Pong;

public class Main {

	public static void main(String[] args) {
		F00Inicio inicio = new F00Inicio();
		//F04MenuJuego m = new F04MenuJuego(false);
	}

}
